# Recap sviluppo — Wild West

## Feature 1 — Sistema mondo base ✅
- Seed procedurale globale (`WorldSeed`, autoload): `rng_for(canale)` dà generatori indipendenti e riproducibili.
- Tempo di gioco e ciclo giorno/notte (`GameTime`, autoload): giorno, ora, fasi (alba/giorno/tramonto/notte), segnali, colore luce.
- Città iniziale (`TownGenerator`): nome, coordinate, strada principale e lotti vuoti nord/sud, tutto come dati.
- Configurazione in `data/world_config.json`.
- Scena `main.tscn` con rendering segnaposto, camera fissa.

## Feature 2 — Player base ✅
- `PlayerState` (autoload): nome, salute, soldi, statistiche (forza, mira, agilità, carisma, resistenza), inventario a slot con stack.
- Nome e distribuzione delle statistiche dipendono dal seed del mondo (canale `player`).
- `ItemDB` (autoload): oggetti definiti in `data/items.json` (razione, bende, whisky, borraccia, fiammiferi).
- Configurazione personaggio in `data/player_config.json`.
- HUD (nome, barra salute, soldi) e scheda personaggio con statistiche e zaino (`scripts/ui/player_hud.gd`). Stile provvisorio, polish nella Feature 4.
- API pronta per le feature future: `damage`, `heal`, `add_money`, `spend_money`, `add_item`, `remove_item`, `use_item`, `to_dict`.
- Debug: R nuova partita, 1/2/3/4 velocità, Spazio pausa, H/J -/+ salute, K +10 soldi, B bende, I scheda, doppio click su un oggetto per usarlo.
- Pronto per: Feature 3 (movimento e camera: il giocatore non ha ancora una posizione nel mondo).

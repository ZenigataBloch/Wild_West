extends Node2D
## Scena principale: genera e mostra la città, applica il ciclo giorno/notte, ospita l'HUD.
## Debug: R nuova partita, 1/2/3/4 velocità tempo, Spazio pausa,
##        H -10 salute, J +10 salute, K +10 soldi, B aggiunge bende, I scheda personaggio.

const CONFIG_PATH := "res://data/world_config.json"

var town: Dictionary = {}
var _town_cfg: Dictionary = {}
var _modulate: CanvasModulate
var _camera: Camera2D
var _info: Label

func _ready() -> void:
	var f := FileAccess.open(CONFIG_PATH, FileAccess.READ)
	_town_cfg = JSON.parse_string(f.get_as_text())["town"]

	_modulate = CanvasModulate.new()
	add_child(_modulate)

	_camera = Camera2D.new()
	add_child(_camera)

	var layer := CanvasLayer.new()
	add_child(layer)
	_info = Label.new()
	_info.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_info.offset_left = 16
	_info.offset_top = -36
	_info.offset_bottom = -8
	_info.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_info.add_theme_font_size_override("font_size", 18)
	layer.add_child(_info)

	add_child(preload("res://scripts/ui/player_hud.gd").new())

	GameTime.phase_changed.connect(func(p): print("Fase: ", p))
	GameTime.day_changed.connect(func(d): print("Giorno ", d))
	PlayerState.player_died.connect(func(): print("Il giocatore è morto"))
	_new_game(0)

func _new_game(forced_seed: int) -> void:
	WorldSeed.new_game(forced_seed)
	GameTime.reset()
	PlayerState.new_character()
	town = TownGenerator.generate(_town_cfg)
	var street: Array = town["street"]
	_camera.position = Vector2(town["origin"][0], town["origin"][1])
	var fit: float = 1100.0 / float(street[2])   # inquadra tutta la strada nella finestra
	_camera.zoom = Vector2(fit, fit)
	queue_redraw()

func _process(_d: float) -> void:
	_modulate.color = GameTime.get_light_color()
	_info.text = "%s  |  Giorno %d  %s  (%s)  |  seed %d  |  x%.0f" % [
		town.get("name", "?"), GameTime.day, GameTime.get_time_string(),
		GameTime.phase, WorldSeed.world_seed, GameTime.time_scale]

func _unhandled_key_input(e: InputEvent) -> void:
	if not e.pressed or e.echo:
		return
	match e.keycode:
		KEY_R: _new_game(0)
		KEY_SPACE: GameTime.paused = not GameTime.paused
		KEY_1: GameTime.time_scale = 1.0
		KEY_2: GameTime.time_scale = 5.0
		KEY_3: GameTime.time_scale = 20.0
		KEY_4: GameTime.time_scale = 60.0
		KEY_H: PlayerState.damage(10)
		KEY_J: PlayerState.heal(10)
		KEY_K: PlayerState.add_money(10)
		KEY_B: PlayerState.add_item("bende", 1)

# Rendering segnaposto: la grafica vera arriva con la Feature 4.
func _draw() -> void:
	if town.is_empty():
		return
	draw_rect(Rect2(-6000, -4000, 12000, 8000), Color("#c9a66b"))        # terreno
	var s: Array = town["street"]
	draw_rect(Rect2(s[0], s[1], s[2], s[3]), Color("#9c7a4a"))           # strada principale
	for lot in town["lots"]:
		var r: Array = lot["rect"]
		draw_rect(Rect2(r[0], r[1], r[2], r[3]), Color("#6b4a2b"))
		draw_rect(Rect2(r[0], r[1], r[2], r[3]), Color("#3b2614"), false, 4.0)

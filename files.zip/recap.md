# Recap sviluppo — Wild West

## Feature 1 — Sistema mondo base ✅
- Seed procedurale globale (`WorldSeed`, autoload): `rng_for(canale)` dà generatori indipendenti e riproducibili.
- Tempo di gioco e ciclo giorno/notte (`GameTime`, autoload): giorno, ora, fasi (alba/giorno/tramonto/notte), segnali, colore luce.
- Città iniziale (`TownGenerator`): nome, coordinate, strada principale e lotti vuoti nord/sud, tutto come dati.
- Configurazione in `data/world_config.json`.
- Scena `main.tscn` con rendering segnaposto, HUD di debug, camera fissa.
- Debug: R nuova partita, 1/2/3/4 velocità, Spazio pausa.
- Pronto per: Feature 2 (player) e Feature 5 (i `lots` accoglieranno gli edifici).

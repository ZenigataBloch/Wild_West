extends CanvasLayer
## HUD del giocatore (nome, salute, soldi) e scheda personaggio (statistiche + inventario).
## Stile western (WesternTheme): barra della salute a fasce di colore, icone, animazioni su danno e soldi (Feature 27).
## Tasto I = apri/chiudi scheda, Esc = chiudi. Doppio click su un oggetto = usalo
## (cibo/medicine) oppure equipaggialo (armi, Feature 12; doppio click sull'arma in mano = la riponi).

signal sheet_toggled(open: bool)

var _name_label: Label
var _hp_bar: ProgressBar
var _hp_fill: StyleBoxFlat
var _heart_icon: WesternIcon
var _pulse_tween: Tween
var _last_health: int = -1
var _last_money: int = -1
var _hp_label: Label
var _money_label: Label
var _weapon_label: Label
var _wound_label: Label
var _debt_label: Label
var _prop_label: Label
var _sheet: CenterContainer
var _sheet_title: Label
var _stats_box: GridContainer
var _sheet_weapon: Label
var _sheet_wounds: Label
var _inv_title: Label
var _inv_list: ItemList

func _ready() -> void:
	layer = 10
	_build_hud()
	_build_version_label()
	_build_sheet()
	PlayerState.name_changed.connect(_refresh_hud.unbind(1))
	PlayerState.health_changed.connect(_refresh_hud.unbind(2))
	PlayerState.money_changed.connect(_refresh_hud.unbind(1))
	PlayerState.stats_changed.connect(_refresh_stats)
	PlayerState.inventory_changed.connect(_refresh_inventory)
	PlayerState.equipment_changed.connect(_refresh_inventory)
	PlayerState.equipment_changed.connect(_refresh_weapon)
	PlayerState.inventory_changed.connect(_refresh_weapon)
	PlayerState.wounds_changed.connect(_refresh_stats)
	PlayerState.wounds_changed.connect(_refresh_wounds)
	_refresh_hud()
	_refresh_stats()
	_refresh_inventory()
	_refresh_weapon()
	_refresh_wounds()
	# Il debito cambia anche senza movimenti di denaro (interessi, scadenze): lo aggiorniamo ogni secondo.
	var debt_timer := Timer.new()
	debt_timer.wait_time = 1.0
	debt_timer.autostart = true
	debt_timer.timeout.connect(_refresh_debt)
	debt_timer.timeout.connect(_refresh_property)
	add_child(debt_timer)
	_refresh_debt()
	_refresh_property()

const GAME_VERSION := "Grafica 2"

# Colori della barra della salute: sana, ferita, grave.
const HP_OK := Color(0.35, 0.48, 0.18)
const HP_MID := Color(0.79, 0.56, 0.12)
const HP_LOW := Color(0.70, 0.15, 0.12)

func _build_version_label() -> void:
	var v := Label.new()
	v.text = "Wild West — %s" % GAME_VERSION
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_theme_color_override("font_color", Color(1, 1, 1, 0.75))
	v.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	v.add_theme_constant_override("shadow_offset_x", 1)
	v.add_theme_constant_override("shadow_offset_y", 1)
	v.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	v.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	v.offset_right = -16
	v.offset_top = 10
	add_child(v)

func _build_hud() -> void:
	var panel := PanelContainer.new()
	WesternTheme.apply(panel)
	panel.position = Vector2(16, 12)
	add_child(panel)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(240, 0)
	box.add_theme_constant_override("separation", 3)
	panel.add_child(box)

	_name_label = Label.new()
	_name_label.theme_type_variation = &"TitleLabel"
	_name_label.add_theme_font_size_override("font_size", 22)
	box.add_child(_name_label)

	var hp_row := HBoxContainer.new()
	hp_row.add_theme_constant_override("separation", 6)
	box.add_child(hp_row)
	_heart_icon = WesternIcon.new()
	_heart_icon.kind = WesternIcon.Kind.HEART
	_heart_icon.icon_size = 24.0
	hp_row.add_child(_heart_icon)
	_hp_bar = ProgressBar.new()
	_hp_bar.show_percentage = false
	_hp_bar.custom_minimum_size = Vector2(0, 20)
	_hp_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hp_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_hp_fill = StyleBoxFlat.new()
	_hp_fill.bg_color = HP_OK
	_hp_fill.set_corner_radius_all(3)
	_hp_bar.add_theme_stylebox_override("fill", _hp_fill)
	hp_row.add_child(_hp_bar)

	_hp_label = Label.new()
	box.add_child(_hp_label)

	var money_row := HBoxContainer.new()
	money_row.add_theme_constant_override("separation", 6)
	box.add_child(money_row)
	var coin := WesternIcon.new()
	coin.kind = WesternIcon.Kind.COIN
	coin.icon_size = 22.0
	money_row.add_child(coin)
	_money_label = Label.new()
	money_row.add_child(_money_label)
	_weapon_label = Label.new()
	box.add_child(_weapon_label)
	_wound_label = Label.new()
	box.add_child(_wound_label)
	_debt_label = Label.new()
	box.add_child(_debt_label)
	_prop_label = Label.new()
	box.add_child(_prop_label)

	var hint := Label.new()
	hint.text = "[I] Scheda  [P] Reputazione  [Q] Missioni"
	hint.modulate = Color(1, 1, 1, 0.6)
	box.add_child(hint)

func _build_sheet() -> void:
	_sheet = CenterContainer.new()
	_sheet.set_anchors_preset(Control.PRESET_FULL_RECT)
	_sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sheet.visible = false
	add_child(_sheet)

	var panel := PanelContainer.new()
	WesternTheme.apply(panel)
	panel.custom_minimum_size = Vector2(520, 0)
	_sheet.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)

	_sheet_title = Label.new()
	_sheet_title.theme_type_variation = &"TitleLabel"
	_sheet_title.add_theme_font_size_override("font_size", 24)
	box.add_child(_sheet_title)
	box.add_child(HSeparator.new())

	var stats_title := Label.new()
	stats_title.text = "Statistiche"
	box.add_child(stats_title)
	_stats_box = GridContainer.new()
	_stats_box.columns = 2
	_stats_box.add_theme_constant_override("h_separation", 40)
	box.add_child(_stats_box)
	box.add_child(HSeparator.new())

	_sheet_weapon = Label.new()
	_sheet_weapon.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_sheet_weapon.custom_minimum_size = Vector2(488, 0)
	box.add_child(_sheet_weapon)
	_sheet_wounds = Label.new()
	_sheet_wounds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_sheet_wounds.custom_minimum_size = Vector2(488, 0)
	box.add_child(_sheet_wounds)
	box.add_child(HSeparator.new())

	_inv_title = Label.new()
	box.add_child(_inv_title)
	_inv_list = ItemList.new()
	_inv_list.custom_minimum_size = Vector2(0, 150)
	_inv_list.item_activated.connect(_on_item_activated)
	box.add_child(_inv_list)

func _unhandled_key_input(e: InputEvent) -> void:
	if not e.pressed or e.echo:
		return
	if e.keycode == KEY_I:
		_set_sheet(not _sheet.visible)
	elif e.keycode == KEY_ESCAPE and _sheet.visible:
		_set_sheet(false)

func _set_sheet(open: bool) -> void:
	_sheet.visible = open
	sheet_toggled.emit(open)

func _refresh_debt() -> void:
	var t := BankSystem.hud_text()
	_debt_label.visible = t != ""
	_debt_label.text = t
	if BankSystem.has_overdue():
		_debt_label.add_theme_color_override("font_color", Color(0.95, 0.4, 0.35))
	else:
		_debt_label.remove_theme_color_override("font_color")

# Proprietà (Feature 18): numero, incassi dei negozi e tasse arretrate; cambiano anche col passare dei giorni.
func _refresh_property() -> void:
	var t := PropertySystem.hud_text()
	_prop_label.visible = t != ""
	_prop_label.text = t
	if PropertySystem.total_dues() > 0:
		_prop_label.add_theme_color_override("font_color", Color(0.95, 0.4, 0.35))
	else:
		_prop_label.remove_theme_color_override("font_color")

func _refresh_hud() -> void:
	_name_label.text = PlayerState.player_name
	_hp_bar.max_value = PlayerState.max_health
	_hp_bar.value = PlayerState.health
	_hp_label.text = "Salute %d / %d" % [PlayerState.health, PlayerState.max_health]
	_money_label.text = "$ %d" % PlayerState.money
	_sheet_title.text = PlayerState.player_name
	var ratio := float(PlayerState.health) / maxf(1.0, float(PlayerState.max_health))
	_hp_fill.bg_color = HP_OK if ratio > 0.6 else (HP_MID if ratio > 0.3 else HP_LOW)
	_set_low_health_pulse(ratio <= 0.25 and PlayerState.health > 0)
	if _last_health >= 0 and PlayerState.health < _last_health:
		_flash(_hp_bar, Color(1.0, 0.4, 0.3))
	if _last_money >= 0 and PlayerState.money != _last_money:
		_pop(_money_label)
	_last_health = int(PlayerState.health)
	_last_money = int(PlayerState.money)

# Il cuore pulsa finché la salute è molto bassa.
func _set_low_health_pulse(on: bool) -> void:
	var running := _pulse_tween != null and _pulse_tween.is_valid()
	if on == running:
		return
	if _pulse_tween != null:
		_pulse_tween.kill()
		_pulse_tween = null
	_heart_icon.modulate = Color.WHITE
	if on:
		_pulse_tween = create_tween().set_loops()
		_pulse_tween.tween_property(_heart_icon, "modulate", Color(1.0, 0.45, 0.4), 0.45)
		_pulse_tween.tween_property(_heart_icon, "modulate", Color.WHITE, 0.45)

# Animazioni brevi che girano anche a gioco in pausa (i pannelli mettono in pausa l'albero).
func _flash(node: CanvasItem, color: Color) -> void:
	node.modulate = color
	var tw := create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.tween_property(node, "modulate", Color.WHITE, 0.35)

func _pop(node: Control) -> void:
	node.pivot_offset = node.size * 0.5
	var tw := create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.tween_property(node, "scale", Vector2.ONE * 1.2, 0.07)
	tw.tween_property(node, "scale", Vector2.ONE, 0.12)

func _refresh_stats() -> void:
	for c in _stats_box.get_children():
		c.queue_free()
	for key in PlayerState.stats:
		var l := Label.new()
		l.text = PlayerState.get_stat_label(key)
		_stats_box.add_child(l)
		var v := Label.new()
		var cur := PlayerState.get_stat(key)
		var base := PlayerState.get_base_stat(key)
		v.text = "%d / %d" % [cur, PlayerState.stat_max]
		if cur < base:
			v.text += "  (ferite %+d)" % (cur - base)
			v.add_theme_color_override("font_color", Color("#e0654a"))
		_stats_box.add_child(v)

func _refresh_inventory() -> void:
	_inv_list.clear()
	var equipped := PlayerState.get_weapon()
	var marked := false
	for slot in PlayerState.inventory:
		var id := String(slot["id"])
		var d := ItemDB.get_item(id)
		var is_weapon := WeaponDB.is_weapon(id)
		var text := "%s  x%d" % [d.get("name", id), slot["qty"]]
		if is_weapon:
			text = "%s  [%s]" % [d.get("name", id), WeaponDB.rarity_label(id)]
			if id == equipped and not marked:
				text += "  (in mano)"
				marked = true
		var idx := _inv_list.add_item(text)
		_inv_list.set_item_metadata(idx, id)
		_inv_list.set_item_tooltip(idx, String(d.get("description", "")))
		if is_weapon:
			_inv_list.set_item_custom_fg_color(idx, WeaponDB.rarity_color(id))
	_inv_title.text = "Zaino (%d/%d) - doppio click per usare / equipaggiare" % [
		PlayerState.inventory.size(), PlayerState.get_slot_limit()]

func _refresh_weapon() -> void:
	var w := PlayerState.get_weapon()
	if w == "":
		_weapon_label.text = "Arma: a mani nude"
		_sheet_weapon.text = "Arma in mano: nessuna (pugni)"
		return
	_weapon_label.text = "Arma: %s" % WeaponDB.name_of(w)
	_sheet_weapon.text = "Arma in mano: %s\n%s" % [WeaponDB.name_of(w), WeaponDB.stats_text(w)]

func _refresh_wounds() -> void:
	var ws := WoundSystem.wounds
	if ws.is_empty():
		_wound_label.text = "Ferite: nessuna"
		_wound_label.modulate = Color.WHITE
		_sheet_wounds.text = "Ferite: nessuna"
		return
	var bleeding := WoundSystem.is_bleeding()
	_wound_label.text = "Ferite: %d%s" % [ws.size(), "  - stai sanguinando!" if bleeding else ""]
	_wound_label.modulate = Color("#ff7a6a") if bleeding else Color.WHITE
	var lines: Array[String] = ["Ferite:"]
	for w in ws:
		var pen := WoundSystem.penalty_text(w)
		lines.append("• %s — %s%s" % [WoundSystem.wound_name(w), WoundSystem.status_text(w), (" [%s]" % pen) if pen != "" else ""])
	_sheet_wounds.text = "\n".join(lines)

func _on_item_activated(index: int) -> void:
	var id := String(_inv_list.get_item_metadata(index))
	if WeaponDB.is_weapon(id):
		if id == PlayerState.get_weapon():
			PlayerState.unequip_weapon()
		else:
			PlayerState.equip_weapon(id)
		return
	PlayerState.use_item(id)
